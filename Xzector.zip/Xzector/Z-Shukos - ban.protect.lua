local version, placeid  = { }, { };
local data, id = game.PlaceVersion, game.PlaceId;
if (data == version[1] and id == placeid[1]) or (data == version[2] and id == placeid[2]) then
elseif (data ~= version[1]) or (data ~= version[2]) then
    return warn('Scripts were disabled')
end;
getgenv().startup = true