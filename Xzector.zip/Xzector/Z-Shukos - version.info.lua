setclipboard(game.PlaceVersion)
