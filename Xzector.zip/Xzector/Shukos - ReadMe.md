some small scripts by Z-Shuko#8287
all rights reserved to Xzector
date - 3/29/2022